import { useEffect, useRef } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { useTheme } from '../Context/ThemeContext';

export default function ThemePanel({ open, onClose }) {
  const { t, i18n } = useTranslation();
  const { themeId, setTheme, themes } = useTheme();
  const ref = useRef(null);
  const rtl = (i18n.resolvedLanguage || i18n.language) === 'ar';

  useEffect(() => {
    if (!open) return;
    const previousFocus = document.activeElement;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    ref.current?.querySelector('button')?.focus();
    function keys(event) {
      if (event.key === 'Escape') onClose();
      if (event.key === 'Tab') {
        const buttons = [...ref.current.querySelectorAll('button')];
        const first = buttons[0], last = buttons[buttons.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
        if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      }
    }
    document.addEventListener('keydown', keys);
    return () => { document.body.style.overflow = previousOverflow; document.removeEventListener('keydown', keys); previousFocus?.focus(); };
  }, [open, onClose]);

  return <AnimatePresence>{open && <motion.div className="modal-backdrop" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose}>
    <motion.section ref={ref} role="dialog" aria-modal="true" aria-labelledby="theme-title" className="theme-panel" onClick={event => event.stopPropagation()} initial={{ x: rtl ? '-100%' : '100%' }} animate={{ x: 0 }} exit={{ x: rtl ? '-100%' : '100%' }} transition={{ duration: 0.25 }}>
      <div className="section-heading"><h2 id="theme-title">{t('theme.title')}</h2><button onClick={onClose}>{t('theme.close')}</button></div>
      <p className="muted">{t('theme.description')}</p>
      {['Light', 'Dark', 'Neon / Hacker', 'Corporate'].map(mode => <fieldset key={mode}><legend>{t(`theme.modes.${mode}`)}</legend><div className="theme-options">{themes.filter(theme => theme.mode === mode).map(theme => <button key={theme.id} aria-pressed={theme.id === themeId} onClick={() => setTheme(theme.id)} className="theme-option"><span className="swatch" style={{ background: theme.vars['--bg'], borderColor: theme.vars['--accent'] }} aria-hidden="true" /><span>{theme.name}</span><span className="tiny">{theme.id === themeId ? t('theme.selected') : t('theme.apply')}</span></button>)}</div></fieldset>)}
    </motion.section>
  </motion.div>}</AnimatePresence>;
}
