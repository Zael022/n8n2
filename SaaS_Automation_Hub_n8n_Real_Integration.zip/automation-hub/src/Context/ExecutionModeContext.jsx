import { createContext, useContext, useMemo, useState } from 'react';

const STORAGE_KEY = 'hub-execution-mode';
const ExecutionModeContext = createContext(null);

function initialSimulationMode() {
  try {
    return localStorage.getItem(STORAGE_KEY) === 'simulation';
  } catch {
    return false;
  }
}

export function ExecutionModeProvider({ children }) {
  const [isSimulationMode, setSimulationModeState] = useState(initialSimulationMode);

  function setSimulationMode(value) {
    const nextValue = Boolean(value);
    setSimulationModeState(nextValue);
    try {
      localStorage.setItem(STORAGE_KEY, nextValue ? 'simulation' : 'real');
    } catch {
      return;
    }
  }

  const value = useMemo(() => ({ isSimulationMode, setSimulationMode }), [isSimulationMode]);
  return <ExecutionModeContext.Provider value={value}>{children}</ExecutionModeContext.Provider>;
}

export function useExecutionMode() {
  const context = useContext(ExecutionModeContext);
  if (!context) throw new Error('useExecutionMode must be used inside ExecutionModeProvider.');
  return context;
}
