# SaaS Automation Hub with n8n integration

Aplicación React con una arquitectura de tres capas para ejecutar automatizaciones reales de n8n sin exponer los webhooks directamente al navegador.

## Arquitectura

```text
React
  |
  | POST /api/n8n/execute/:workflowName
  v
Node.js and Express proxy
  |
  | POST /webhook/:workflowPath
  v
n8n
  |
  | Respond to Webhook
  v
Express proxy
  |
  v
React
```

El modo simulado anterior se conserva como respaldo manual. El estado global se guarda en localStorage con la clave `hub-execution-mode`. El modo real es el valor inicial cuando todavía no existe una preferencia guardada.

## Requisitos

- Node.js 22.12 o posterior.
- Una instancia de n8n accesible desde el backend Express.
- El workflow correspondiente debe estar publicado o activo cuando se utilice la URL de producción de n8n.

## Instalación

```bash
npm install
npm run dev
```

El comando inicia:

- Frontend Vite en `http://127.0.0.1:5173`.
- Backend Express en `http://127.0.0.1:3001`.

La dependencia de JSON Server fue eliminada. Express ahora sirve los datos locales de workflows y logs, persiste los nuevos logs en `db.json` y actúa como proxy de n8n.

## Configuración del backend

Copie `.env.example` como `.env` si desea cambiar la configuración predeterminada.

```text
PORT=3001
HOST=127.0.0.1
N8N_WEBHOOK_BASE_URL=http://127.0.0.1:5678/webhook
N8N_TIMEOUT_MS=30000
N8N_FINANCE_WEBHOOK_PATH=finance
N8N_HR_WEBHOOK_PATH=hr
N8N_SUPPORT_WEBHOOK_PATH=support
N8N_SALES_WEBHOOK_PATH=sales
N8N_LOGISTICS_WEBHOOK_PATH=logistics
```

El backend usa una lista permitida de cinco nombres de workflow. El parámetro recibido desde React no se utiliza como una URL arbitraria.

## Endpoint de ejecución

El frontend envía una solicitud como esta:

```text
POST /api/n8n/execute/finance
Content-Type: application/json
```

El backend la reenvía a:

```text
http://127.0.0.1:5678/webhook/finance
```

Una ejecución correcta devuelve al frontend una respuesta del proxy con esta forma:

```json
{
  "status": "completed",
  "workflow": "finance",
  "data": {
    "status": "completed",
    "message": "Finance webhook executed",
    "data": {
      "supplier": "Northwind Services",
      "amount": 1250
    },
    "timestamp": "2026-09-18T16:00:00.000Z"
  },
  "timestamp": "2026-09-18T16:00:00.010Z"
}
```

Cuando n8n no responde, el proxy devuelve HTTP 502 con un error estructurado. El frontend muestra el error y permite cambiar manualmente a modo simulado desde la barra superior.

## Configuración en n8n

Se incluye `n8n-workflow-finance-webhook.json`, que contiene únicamente un nodo Webhook y un nodo Respond to Webhook.

Para probarlo:

1. Importe `n8n-workflow-finance-webhook.json` en n8n.
2. Abra el nodo `Finance Webhook`.
3. Verifique que el método HTTP sea `POST`.
4. Verifique que el path sea `finance`.
5. Configure `Respond` como `Using Respond to Webhook Node`.
6. Publique o active el workflow para registrar la Production URL.
7. Verifique que la URL de producción termine en `/webhook/finance` si utiliza la configuración predeterminada del backend.
8. Abra `Respond to Webhook` y mantenga `Respond With` en `JSON`.
9. Inicie esta aplicación con `npm run dev`.
10. En la barra superior seleccione `Modo real (n8n)` y ejecute Finance.

n8n mantiene URLs separadas para pruebas y producción. La Test URL requiere que n8n esté escuchando eventos de prueba. Para esta aplicación se recomienda la Production URL de un workflow publicado o activo.

## Contrato recomendado de respuesta de n8n

Cada workflow real debería terminar con Respond to Webhook y devolver una estructura equivalente a:

```json
{
  "status": "completed",
  "message": "Workflow completed",
  "data": {},
  "timestamp": "2026-09-18T16:00:00.000Z"
}
```

Los valores reconocidos por el frontend para `status` incluyen `completed`, `success`, `rejected`, `no action`, `no_action` y `noop`.

## Modo real y modo simulado

`src/Context/ExecutionModeContext.jsx` mantiene el estado global.

- Modo real: `src/lib/n8nService.js` hace POST al backend Express.
- Modo simulado: `src/lib/n8nService.js` reutiliza `src/lib/simulate.js` y no llama a n8n.
- El toggle se encuentra en `src/Componentes/ExecutionModeToggle.jsx`.
- `src/Pages/Simulator.jsx` mantiene progreso, cancelación, estados de red, persistencia y descarga de resultados en ambos modos.

No existe fallback automático después de un error de n8n. Esto es intencional para no convertir silenciosamente una ejecución real fallida en una simulación. El usuario decide cuándo cambiar al respaldo simulado.

## Internacionalización

La aplicación conserva exactamente seis idiomas:

- English
- Mandarin Chinese
- Hindi
- Spanish
- French
- Arabic

El selector utiliza i18next, react-i18next e i18next-browser-languagedetector. La preferencia se persiste en `hub-language`. Árabe cambia dinámicamente el documento a `dir="rtl"`; los demás idiomas utilizan `dir="ltr"`.

Los textos del nuevo modo de ejecución están disponibles en los seis diccionarios.

## Archivos principales

| Archivo | Responsabilidad |
| --- | --- |
| `server.js` | API Express, persistencia local y proxy seguro hacia n8n |
| `.env.example` | Configuración de URL, timeout y paths de webhook |
| `src/lib/n8nService.js` | Selección entre ejecución real y simulada |
| `src/Context/ExecutionModeContext.jsx` | Estado global y persistencia del modo |
| `src/Componentes/ExecutionModeToggle.jsx` | Interruptor accesible de modo |
| `src/Pages/Simulator.jsx` | Ejecución, progreso, cancelación, errores y resultados |
| `n8n-workflow-finance-webhook.json` | Workflow mínimo importable para probar Finance |
| `db.json` | Definición local de escenarios e historial de ejecución |

## Comandos de validación

```bash
npm test
npm run build
npx playwright install chromium
npm run test:e2e
```

Para probar únicamente el backend:

```bash
npm run server
```

Comprobación básica:

```text
GET http://127.0.0.1:3001/api/health
```

## Consideraciones de producción

Este proxy evita exponer la URL de n8n al navegador, pero una instalación empresarial debería agregar autenticación y autorización de usuarios, límites de tasa, gestión centralizada de secretos, TLS, observabilidad, almacenamiento transaccional de logs y controles de acceso al webhook de n8n.
