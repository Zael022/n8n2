import test from 'node:test';
import assert from 'node:assert/strict';
import { executeWorkflow } from '../src/lib/n8nService.js';

test('execution service keeps the local simulator as an explicit fallback', async () => {
  const result = await executeWorkflow('finance', {
    supplier: 'Northwind Services',
    amount: 1250,
    date: '2026-09-18',
    attachment: 'invoice.pdf'
  }, { isSimulationMode: true });

  assert.equal(result.status, 'Completed');
  assert.equal(result.source, 'simulation');
  assert.equal(result.output.row.amount, 1250);
});

test('execution service normalizes a successful n8n proxy response', async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => new Response(JSON.stringify({
    status: 'completed',
    workflow: 'finance',
    data: {
      status: 'completed',
      message: 'Finance webhook executed',
      data: { accepted: true },
      timestamp: '2026-09-18T16:00:00.000Z'
    },
    timestamp: '2026-09-18T16:00:00.010Z'
  }), { status: 200, headers: { 'content-type': 'application/json' } });

  try {
    const result = await executeWorkflow('finance', { supplier: 'Northwind Services' }, { isSimulationMode: false });
    assert.equal(result.status, 'Completed');
    assert.equal(result.source, 'n8n');
    assert.equal(result.message, 'Finance webhook executed');
    assert.deepEqual(result.output, { accepted: true });
  } finally {
    globalThis.fetch = originalFetch;
  }
});
