import { test, expect } from '@playwright/test';
test.beforeEach(async ({ page }) => {
  await page.addInitScript(() => localStorage.setItem('hub-execution-mode', 'simulation'));
  await page.route('https://api.frankfurter.dev/**', route => route.fulfill({ json:{ date:'2026-09-18', base:'EUR', quote:'USD', rate:1.15 } }));
});
test('Dashboard, local media, all themes and persistence', async ({ page }) => {
  const errors = []; page.on('pageerror', error => errors.push(error.message));
  await page.goto('/');
  await expect(page.getByText('System Online', { exact:true })).toBeVisible();
  await expect(page.locator('.workflow-card')).toHaveCount(3);
  await expect.poll(() => page.locator('video').evaluate(video => video.readyState)).toBeGreaterThan(1);
  await page.screenshot({ path:'tests/dashboard-preview.png', fullPage:true });
  await page.getByRole('button', { name:/Appearance/ }).click();
  const options = page.locator('.theme-option'); await expect(options).toHaveCount(12);
  for (let i=0;i<12;i++) { await options.nth(i).click(); await expect(options.nth(i)).toHaveAttribute('aria-pressed','true'); }
  await page.getByRole('button', { name:'Close', exact:true }).click();
  await page.getByRole('link', { name:'Execution logs', exact:true }).click();
  await expect(page.locator('html')).toHaveAttribute('data-theme','monochromatic');
  await page.reload(); await expect(page.locator('html')).toHaveAttribute('data-theme','monochromatic');
  expect(errors).toEqual([]);
});
test('Nine-card carousel slides in both directions and remembers page', async ({ page }) => {
  await page.goto('/logs'); await expect(page.locator('.log-card')).toHaveCount(9);
  const first = await page.locator('.log-card').first().textContent();
  await expect(page.getByRole('button', { name:'Previous',exact:true })).toBeDisabled();
  await page.getByRole('button', { name:'Next',exact:true }).click();
  await expect(page.getByText('Page 2 of 3')).toBeVisible();
  await expect(page.locator('.log-card').first()).not.toHaveText(first);
  await expect(page.getByRole('button', { name:'Previous',exact:true })).toBeEnabled();
  await page.getByRole('button', { name:'Previous',exact:true }).click();
  await expect(page.locator('.log-card').first()).toHaveText(first);
  await page.getByRole('button', { name:'Next',exact:true }).click();
  await expect(page.getByRole('button', { name:'Next',exact:true })).toBeEnabled();
  await page.getByRole('link', { name:'Overview',exact:true }).click();
  await page.getByRole('link', { name:'Execution logs',exact:true }).click();
  await expect(page.getByText('Page 2 of 3')).toBeVisible();
  await page.getByRole('button', { name:'Next',exact:true }).click();
  await expect(page.getByText('Page 3 of 3')).toBeVisible();
  await expect(page.getByRole('button', { name:'Next',exact:true })).toBeDisabled();
});
test('All five simulated flows save records to the local API', async ({ page, request }) => {
  for (const id of ['finance','hr','support','sales','logistics']) {
    await page.goto(`/simulator/${id}`);
    await expect(page.getByLabel('Edit input JSON')).not.toHaveValue('');
    await page.getByRole('button', { name:'Run simulation',exact:true }).click();
    await expect(page.getByText('Finished',{exact:true})).toBeVisible();
  }
  const logs = await (await request.get('http://127.0.0.1:3001/api/logs')).json();
  expect(logs.filter(log => !log.seed)).toHaveLength(5);
  await page.reload(); await page.getByRole('button',{name:'Alternate case'}).click();
  await page.getByRole('button',{name:'Run simulation',exact:true}).click();
  await expect(page.getByText('Stock levels are sufficient. No notification needed.',{exact:true})).toBeVisible();
});
test('Cancellation, invalid JSON, save failure and idempotent retry', async ({ page, request }) => {
  await page.goto('/simulator/finance');
  await expect(page.getByLabel('Edit input JSON')).not.toHaveValue('');
  const before = (await (await request.get('http://127.0.0.1:3001/api/logs')).json()).length;
  await page.getByRole('button', {name:'Run simulation',exact:true}).click();
  await page.getByRole('button', {name:'Cancel',exact:true}).click();
  await expect(page.getByText('Cancelled',{exact:true})).toBeVisible();
  expect((await (await request.get('http://127.0.0.1:3001/api/logs')).json()).length).toBe(before);
  await page.getByLabel('Edit input JSON').fill('{');
  await page.getByRole('button', {name:'Run simulation',exact:true}).click();
  await expect(page.getByRole('alert')).toContainText('valid JSON');
  await page.getByRole('button', {name:'Load sample'}).click();
  await page.route('**/api/logs', route => route.request().method() === 'POST' ? route.abort() : route.continue());
  await page.getByRole('button', {name:'Run simulation',exact:true}).click();
  await expect(page.getByText('Unsaved',{exact:true})).toBeVisible();
  await page.unroute('**/api/logs');
  await page.getByRole('button', {name:'Retry saving log'}).click();
  await expect(page.getByText('Finished',{exact:true})).toBeVisible();
  const logs = await (await request.get('http://127.0.0.1:3001/api/logs')).json();
  expect(logs.length).toBe(before+1);
  const last=logs[logs.length-1];
  await request.post('http://127.0.0.1:3001/api/logs', { data:last });
  expect((await (await request.get('http://127.0.0.1:3001/api/logs')).json()).length).toBe(before+1);
});
test('Mobile layout, details video, search and offline state', async ({ page }) => {
  await page.setViewportSize({ width:390,height:844 });
  for (const path of ['/','/workflows','/workflows/finance','/simulator/finance','/logs']) {
    await page.goto(path); await expect(page.locator('.loading')).toHaveCount(0);
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBeTruthy();
    if(path === '/logs') {
      await expect(page.locator('.log-card')).toHaveCount(9);
      expect(await page.locator('.logs-grid').evaluate(element => getComputedStyle(element).gridTemplateColumns.split(' ').length)).toBe(3);
      await page.screenshot({ path:'tests/mobile-logs-preview.png',fullPage:true });
    }
  }
  await page.goto('/workflows'); await page.getByRole('searchbox').fill('logistics');
  await expect(page.locator('.workflow-card')).toHaveCount(1);
  await page.goto('/workflows/finance');
  await page.getByRole('button',{name:'Play video',exact:true}).click();
  await expect.poll(() => page.locator('video').evaluate(video => video.currentTime)).toBeGreaterThan(0);
  await page.getByRole('button',{name:'Pause video',exact:true}).click();
  await expect(page.locator('video')).toHaveJSProperty('paused',true);
  await page.route('https://api.frankfurter.dev/**', route => route.abort());
  await page.goto('/'); await expect(page.getByText('Data unavailable',{exact:true})).toBeVisible();
});
