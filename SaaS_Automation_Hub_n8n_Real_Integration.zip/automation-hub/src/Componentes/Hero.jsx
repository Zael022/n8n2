import { useState } from 'react';
import { Link } from 'react-router-dom';
import ReactPlayer from 'react-player/file';
import { useReducedMotion } from 'framer-motion';
import { useTranslation } from 'react-i18next';

export default function Hero() {
  const { t } = useTranslation();
  const reduced = useReducedMotion();
  const [paused, setPaused] = useState(false);
  const [error, setError] = useState(false);
  const description = t('hero.description').split('\n');
  return <section className="hero">
    <div className="hero-video" aria-hidden="true"><ReactPlayer url="/media/data-flow.webm" playing={!paused && !reduced} muted loop controls={false} playsinline width="100%" height="100%" onError={() => setError(true)} /></div>
    <div className="hero-content">
      <p className="eyebrow">{t('hero.eyebrow')}</p>
      <h1>{t('hero.title1')}<br /><span>{t('hero.title2')}</span></h1>
      <p>{description.map((line, index) => <span key={line}>{index > 0 && <br />}{line}</span>)}</p>
      <div className="actions"><Link className="button primary" to="/workflows">{t('hero.explore')}</Link><Link className="button hero-secondary" to="/simulator/finance">{t('hero.launch')}</Link></div>
      <p className="hero-caption">{t('hero.caption')}</p>
    </div>
    {!error && !reduced && <button className="video-toggle" onClick={() => setPaused(value => !value)}>{paused ? t('hero.play') : t('hero.pause')}</button>}
  </section>;
}
