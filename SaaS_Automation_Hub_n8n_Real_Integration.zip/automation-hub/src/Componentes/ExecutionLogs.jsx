import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useHub } from '../Context/HubContext';
import { PAGE_SIZE, pageItems } from '../lib/simulate';
import { downloadJson } from '../lib/api';
import { localizeWorkflow } from '../lib/localizeWorkflow';

const slide = {
  enter: direction => ({ x: direction > 0 ? '100%' : '-100%', opacity: 0 }),
  center: { x: 0, opacity: 1 },
  exit: direction => ({ x: direction > 0 ? '-100%' : '100%', opacity: 0 })
};

export default function ExecutionLogs() {
  const { t, i18n } = useTranslation();
  const { logs, workflows, page, setPage, direction, setDirection, refresh, loading } = useHub();
  const reduced = useReducedMotion();
  const [moving, setMoving] = useState(false);
  const total = Math.max(1, Math.ceil(logs.length / PAGE_SIZE));
  const current = Math.min(page, total);
  const locale = i18n.resolvedLanguage || i18n.language;

  useEffect(() => { if (page > total) setPage(total); }, [page, total, setPage]);

  function changePage(next) {
    if (moving || next < 1 || next > total) return;
    setDirection(next > current ? 1 : -1);
    setMoving(true);
    setPage(next);
  }

  function workflowFor(log) {
    const workflow = workflows.find(item => item.id === log.workflow_id);
    return workflow ? localizeWorkflow(workflow, t) : null;
  }

  return <section aria-label={t('logs.aria')}>
    <div className="section-heading">
      <div><p className="eyebrow">{t('logs.eyebrow')}</p><h1>{t('logs.title')}</h1><p className="muted">{t('logs.description')}</p></div>
      <div className="actions"><button onClick={() => refresh()} disabled={loading}>{t('logs.refresh')}</button><button onClick={() => downloadJson('execution-logs.json', logs)} disabled={!logs.length}>{t('logs.export')}</button></div>
    </div>
    <div className="log-toolbar"><span>{t('logs.count', { count: logs.length })}</span><span aria-live="polite">{t('logs.page', { current, total })}</span></div>
    {!logs.length && !loading ? <div className="panel empty">{t('logs.empty')}</div> : null}
    <div className="carousel-window" aria-busy={moving}>
      <AnimatePresence initial={false} mode="wait" custom={direction}>
        <motion.div key={current} custom={direction} variants={reduced ? undefined : slide}
          initial="enter" animate="center" exit="exit" transition={{ duration: reduced ? 0 : 0.3, ease: 'easeInOut' }}
          onAnimationComplete={() => setMoving(false)} className="logs-grid" data-testid="logs-grid">
          {pageItems(logs, current).map(log => {
            const localized = workflowFor(log);
            return <article className="log-card" key={log.id}>
            <div className="flex justify-between gap-3"><span className="eyebrow">{localized?.department || log.department}</span><span className="badge">{t(`logs.status.${log.status}`, { defaultValue: log.status })}</span></div>
            <h2>{localized?.title || log.title}</h2><p className="muted">{log.seed && localized ? localized.stages.at(-1) : log.message}</p>
            <div className="log-meta"><time dateTime={log.timestamp}>{new Date(log.timestamp).toLocaleString(locale)}</time><span>{(log.duration_ms / 1000).toFixed(1)}s</span></div>
            <p className="tiny muted">{log.seed ? t('logs.seed') : log.simulated ? t('logs.simulated') : t('logs.real')} / {log.id}</p>
          </article>;
          })}
        </motion.div>
      </AnimatePresence>
    </div>
    <nav className="pagination" aria-label={t('logs.pagination')}><button disabled={current <= 1 || moving} onClick={() => changePage(current - 1)}>{t('logs.previous')}</button><span>{current} / {total}</span><button disabled={current >= total || moving} onClick={() => changePage(current + 1)}>{t('logs.next')}</button></nav>
  </section>;
}
