import { useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';

export default function MarketPanel() {
  const { t, i18n } = useTranslation();
  const [data, setData] = useState(null);
  const [status, setStatus] = useState('connecting');
  const [checked, setChecked] = useState(null);
  const [busy, setBusy] = useState(false);
  const refreshRef = useRef(() => {});
  const locale = i18n.resolvedLanguage || i18n.language;

  useEffect(() => {
    let alive = true, timer, active;
    const refresh = async () => {
      if (active) return;
      clearTimeout(timer);
      active = new AbortController();
      setBusy(true);
      const timeout = setTimeout(() => active?.abort(), 8000);
      try {
        const response = await fetch('https://api.frankfurter.dev/v2/rate/eur/usd', { signal: active.signal });
        if (!response.ok) throw new Error('API unavailable');
        const json = await response.json();
        if (!Number.isFinite(json.rate) || typeof json.date !== 'string') throw new Error('Invalid response');
        if (alive) { setData(json); setChecked(new Date()); setStatus('online'); }
      } catch {
        if (alive) setStatus('unavailable');
      } finally {
        clearTimeout(timeout);
        active = null;
        if (alive) { setBusy(false); timer = setTimeout(refresh, 15000); }
      }
    };
    refreshRef.current = refresh;
    refresh();
    return () => { alive = false; clearTimeout(timer); active?.abort(); };
  }, []);

  const statusLabel = status === 'online' ? t('market.online') : status === 'unavailable' ? t('market.unavailable') : t('market.connecting');
  return <aside className="market panel" aria-label={t('market.aria')}>
    <div className="flex items-center justify-between gap-3"><p className="eyebrow">{t('market.eyebrow')}</p><span className={status === 'online' ? 'online status' : 'status'}>{statusLabel}</span></div>
    <div className="market-rate"><span>EUR / USD</span><strong>{data ? data.rate.toFixed(4) : t('market.rateUnavailable')}</strong></div>
    <p className="muted tiny">{t('market.description')}</p>
    <p className="tiny muted">{t('market.rateDate', { date: data?.date || t('market.notReceived') })}<br />{t('market.lastSuccess', { time: checked?.toLocaleTimeString(locale) || t('market.notReceived') })}{status === 'unavailable' && data ? ` (${t('market.stale')})` : ''}</p>
    <div className="actions"><button onClick={() => refreshRef.current()} disabled={busy}>{busy ? t('market.checking') : t('market.check')}</button><a href="https://frankfurter.dev/" target="_blank" rel="noreferrer">{t('market.source')}</a></div>
  </aside>;
}
