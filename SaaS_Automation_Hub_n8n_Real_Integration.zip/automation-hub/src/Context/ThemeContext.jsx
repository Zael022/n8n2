import { createContext, useContext, useEffect, useState } from 'react';
import { resolveTheme, themes } from '../lib/themes';
const ThemeContext = createContext(null);
export function ThemeProvider({ children }) {
  const [themeId, setThemeId] = useState(() => {
    try { return resolveTheme(localStorage.getItem('hub-theme')).id; }
    catch { return 'classic-dark'; }
  });
  const selectedTheme = resolveTheme(themeId);
  useEffect(() => {
    Object.entries(selectedTheme.vars).forEach(([key, value]) => document.documentElement.style.setProperty(key, value));
    document.documentElement.dataset.theme = selectedTheme.id;
    document.documentElement.style.colorScheme = ['Dark', 'Neon / Hacker'].includes(selectedTheme.mode) ? 'dark' : 'light';
    try { localStorage.setItem('hub-theme', selectedTheme.id); } catch { /* Session theme remains available. */ }
  }, [selectedTheme]);
  return <ThemeContext.Provider value={{ themeId, selectedTheme, themes, setTheme: id => setThemeId(resolveTheme(id).id) }}>{children}</ThemeContext.Provider>;
}
export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) throw new Error('useTheme requires ThemeProvider');
  return context;
}
