import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { applyDocumentLanguage, supportedLanguages } from '../i18n';

export default function LanguageSwitcher() {
  const { i18n, t } = useTranslation();
  const [open, setOpen] = useState(false);
  const rootRef = useRef(null);
  const itemRefs = useRef([]);
  const reduced = useReducedMotion();
  const currentCode = String(i18n.resolvedLanguage || i18n.language || 'en').split('-')[0];
  const current = supportedLanguages.find(language => language.code === currentCode) || supportedLanguages[0];

  useEffect(() => {
    function handleOutside(event) {
      if (!rootRef.current?.contains(event.target)) setOpen(false);
    }
    document.addEventListener('pointerdown', handleOutside);
    return () => document.removeEventListener('pointerdown', handleOutside);
  }, []);

  async function selectLanguage(code) {
    try { localStorage.setItem('hub-language', code); } catch {}
    applyDocumentLanguage(code);
    await i18n.changeLanguage(code);
    setOpen(false);
    rootRef.current?.querySelector('.language-trigger')?.focus();
  }

  function handleTriggerKeyDown(event) {
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
      event.preventDefault();
      setOpen(true);
      requestAnimationFrame(() => {
        const index = event.key === 'ArrowDown' ? 0 : supportedLanguages.length - 1;
        itemRefs.current[index]?.focus();
      });
    }
  }

  function handleMenuKeyDown(event, index) {
    if (event.key === 'Escape') {
      event.preventDefault();
      setOpen(false);
      rootRef.current?.querySelector('.language-trigger')?.focus();
      return;
    }
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
      event.preventDefault();
      const offset = event.key === 'ArrowDown' ? 1 : -1;
      const next = (index + offset + supportedLanguages.length) % supportedLanguages.length;
      itemRefs.current[next]?.focus();
    }
  }

  return <div className="language-switcher" ref={rootRef}>
    <button
      type="button"
      className="language-trigger"
      aria-haspopup="menu"
      aria-expanded={open}
      aria-controls="language-menu"
      aria-label={t('language.select')}
      onClick={() => setOpen(value => !value)}
      onKeyDown={handleTriggerKeyDown}
    >
      <span className="language-code">{current.shortLabel}</span>
      <span className="language-name">{current.label}</span>
      <span className="language-caret" aria-hidden="true">v</span>
    </button>
    <AnimatePresence>
      {open && <motion.div
        id="language-menu"
        className="language-menu"
        role="menu"
        aria-label={t('language.menu')}
        initial={reduced ? false : { opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        exit={reduced ? { opacity: 0 } : { opacity: 0, y: -8 }}
        transition={{ duration: reduced ? 0 : 0.16 }}
      >
        {supportedLanguages.map((language, index) => <button
          key={language.code}
          type="button"
          role="menuitemradio"
          aria-checked={language.code === current.code}
          ref={element => { itemRefs.current[index] = element; }}
          onClick={() => selectLanguage(language.code)}
          onKeyDown={event => handleMenuKeyDown(event, index)}
        >
          <span>{language.shortLabel}</span>
          <span>{language.label}</span>
          <span className="language-selected">{language.code === current.code ? t('language.active') : ''}</span>
        </button>)}
      </motion.div>}
    </AnimatePresence>
  </div>;
}
