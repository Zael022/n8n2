import { motion, useReducedMotion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { localizeWorkflow } from '../lib/localizeWorkflow';

export default function WorkflowCard({ workflow, index = 0 }) {
  const { t } = useTranslation();
  const reduced = useReducedMotion();
  const localized = localizeWorkflow(workflow, t);
  return <motion.article className="workflow-card" whileHover={reduced ? {} : { y: -6 }} transition={{ duration: 0.2 }}>
    <div className="flex justify-between items-center"><span className="eyebrow">{localized.department}</span><span className="card-number">{String(index + 1).padStart(2, '0')}</span></div>
    <h3>{localized.title}</h3><p className="muted">{localized.business_problem}</p>
    <p className="tiny trigger">{localized.trigger_used.split(':')[0]}</p>
    <div className="card-actions"><Link className="button" to={`/workflows/${workflow.id}`}>{t('workflows.diagram')}</Link><Link className="text-link" to={`/simulator/${workflow.id}`}>{t('workflows.simulate')}</Link></div>
  </motion.article>;
}
