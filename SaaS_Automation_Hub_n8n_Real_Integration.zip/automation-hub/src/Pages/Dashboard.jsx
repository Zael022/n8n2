import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useHub } from '../Context/HubContext';
import Hero from '../Componentes/Hero';
import MarketPanel from '../Componentes/MarketPanel';
import WorkflowCard from '../Componentes/WorkflowCard';

export default function Dashboard() {
  const { t } = useTranslation();
  const { workflows, logs } = useHub();
  const runs = logs.filter(log => !log.seed);
  const learnTitle = t('dashboard.learnTitle').split('\n');
  return <>
    <Hero />
    <section className="overview-strip">
      <div><span className="metric-number">{String(workflows.length).padStart(2, '0')}</span><p>{t('dashboard.businessWorkflows')}</p></div>
      <div><span className="metric-number">12</span><p>{t('dashboard.themes')}</p></div>
      <div><span className="metric-number">{String(runs.length).padStart(2, '0')}</span><p>{t('dashboard.runs')}</p></div>
      <div><span className="metric-number">{runs.length ? Math.round(runs.filter(log => log.status === 'Completed').length / runs.length * 100) + '%' : 'N/A'}</span><p>{t('dashboard.completed')}</p></div>
    </section>
    <section>
      <div className="section-heading"><div><p className="eyebrow">{t('dashboard.eyebrow')}</p><h2>{t('dashboard.title')}</h2></div><Link className="text-link" to="/workflows">{t('dashboard.all')}</Link></div>
      <div className="workflow-grid">{workflows.slice(0, 3).map((workflow, index) => <WorkflowCard key={workflow.id} workflow={workflow} index={index} />)}</div>
    </section>
    <section className="bottom-grid">
      <div className="panel editorial"><p className="eyebrow">{t('dashboard.learn')}</p><h2>{learnTitle.map((line, index) => <span key={line}>{index > 0 && <br />}{line}</span>)}</h2><p className="muted">{t('dashboard.learnDescription')}</p><Link className="text-link" to="/simulator/finance">{t('dashboard.open')}</Link></div>
      <MarketPanel />
    </section>
  </>;
}
