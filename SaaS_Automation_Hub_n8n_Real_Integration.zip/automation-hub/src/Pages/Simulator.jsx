import { useEffect, useRef, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { useHub } from '../Context/HubContext';
import { useExecutionMode } from '../Context/ExecutionModeContext';
import { localizeWorkflow, localizeWorkflows } from '../lib/localizeWorkflow';
import { executeWorkflow } from '../lib/n8nService';
import { downloadJson } from '../lib/api';
import NotFound from './NotFound';
import styles from './Simulator.module.css';

function delay(ms, signal) {
  return new Promise((resolve, reject) => {
    if (signal.aborted) return reject(new DOMException('Cancelled', 'AbortError'));
    const cancel = () => { clearTimeout(timer); reject(new DOMException('Cancelled', 'AbortError')); };
    const timer = setTimeout(() => { signal.removeEventListener('abort', cancel); resolve(); }, ms);
    signal.addEventListener('abort', cancel, { once: true });
  });
}

export default function Simulator() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { workflows, loading, error: apiError, saveLog } = useHub();
  const { isSimulationMode } = useExecutionMode();
  const workflow = workflows.find(item => item.id === id);
  const localized = localizeWorkflow(workflow, t);
  const localizedWorkflows = localizeWorkflows(workflows, t);
  const [input, setInput] = useState('');
  const [phase, setPhase] = useState('Idle');
  const [step, setStep] = useState(-1);
  const [runStages, setRunStages] = useState(null);
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const [pending, setPending] = useState(null);
  const controller = useRef(null);
  const lock = useRef(false);
  const alive = useRef(true);

  useEffect(() => { alive.current = true; return () => { alive.current = false; controller.current?.abort(); }; }, []);
  useEffect(() => { if (workflow) setInput(JSON.stringify(workflow.sample_input, null, 2)); }, [workflow]);

  const busy = phase === 'Running' || phase === 'Saving';

  async function persist(log) {
    setPhase('Saving');
    try {
      await saveLog(log);
      if (alive.current) { setPending(null); setPhase('Finished'); }
    } catch (err) {
      if (alive.current) { setPending(log); setError(t('simulator.saveFailed', { message: err.message })); setPhase('Unsaved'); }
    }
  }

  async function run() {
    if (lock.current || pending) return;
    let payload;
    try {
      payload = JSON.parse(input);
      if (!payload || typeof payload !== 'object' || Array.isArray(payload)) throw new Error(t('simulator.objectRequired'));
    } catch (err) {
      setError(err instanceof SyntaxError ? t('simulator.validJson') : err.message);
      return;
    }

    const initialStages = localized.stages;
    setRunStages(initialStages);
    lock.current = true;
    setError('');
    setResult(null);
    setPhase('Running');
    setStep(0);
    const started = performance.now();
    const current = new AbortController();
    controller.current = current;
    let progressTimer;

    try {
      if (isSimulationMode) {
        for (let index = 0; index < initialStages.length; index += 1) {
          setStep(index);
          await delay(500, current.signal);
        }
      } else {
        progressTimer = window.setInterval(() => {
          setStep(previous => Math.min(previous + 1, Math.max(0, initialStages.length - 1)));
        }, 900);
      }

      const computed = await executeWorkflow(id, payload, { isSimulationMode, signal: current.signal });
      const stages = computed.status === 'Rejected'
        ? [localized.stages[0], t('simulator.stages.validating'), t('simulator.stages.rejection')]
        : computed.status === 'No action'
          ? [...localized.stages.slice(0, -1), t('simulator.stages.noNotification')]
          : localized.stages;

      if (progressTimer) window.clearInterval(progressTimer);
      setRunStages(stages);
      setStep(stages.length);
      const log = {
        id: crypto.randomUUID(),
        workflow_id: id,
        status: computed.status,
        message: computed.message,
        duration_ms: Math.round(performance.now() - started),
        simulated: isSimulationMode
      };
      if (alive.current) { setResult(computed); await persist(log); }
    } catch (err) {
      if (progressTimer) window.clearInterval(progressTimer);
      if (alive.current) {
        setPhase(err.name === 'AbortError' ? 'Cancelled' : 'Error');
        if (err.name !== 'AbortError') setError(isSimulationMode ? err.message : t('simulator.realFailed', { message: err.message }));
      }
    } finally {
      lock.current = false;
      controller.current = null;
    }
  }

  if (!workflow) return loading || apiError ? null : <NotFound />;
  const executionStages = runStages || localized.stages;
  const progress = phase === 'Finished' || phase === 'Saving' || phase === 'Unsaved' ? 100 : Math.max(0, step) / executionStages.length * 100;

  return <section>
    <p className="eyebrow">{isSimulationMode ? t('simulator.eyebrowSimulation') : t('simulator.eyebrowReal')}</p>
    <h1>{t('simulator.title')}</h1>
    <p className="muted lead">{isSimulationMode ? t('simulator.descriptionSimulation') : t('simulator.descriptionReal')}</p>
    <div className="mode-notice" role="status">
      <strong>{isSimulationMode ? t('executionMode.simulation') : t('executionMode.real')}</strong>
      <span>{isSimulationMode ? t('executionMode.simulationDescription') : t('executionMode.realDescription')}</span>
    </div>
    <label className="search">{t('simulator.choose')}<select value={id} disabled={busy || Boolean(pending)} onChange={event => navigate(`/simulator/${event.target.value}`)}>{localizedWorkflows.map(item => <option key={item.id} value={item.id}>{item.department}: {item.title}</option>)}</select></label>
    <div className={styles.grid}>
      <div className="panel">
        <p className="eyebrow">{t('simulator.input')}</p>
        <h2>{localized.title}</h2>
        <div className="actions my-5"><button disabled={busy || Boolean(pending)} onClick={() => { setInput(JSON.stringify(workflow.sample_input, null, 2)); setError(''); }}>{t('simulator.sample')}</button><button disabled={busy || Boolean(pending)} onClick={() => { setInput(JSON.stringify(workflow.alternate_input, null, 2)); setError(''); }}>{t('simulator.alternate')}</button></div>
        <label htmlFor="input-json">{t('simulator.edit')}</label>
        <textarea id="input-json" className={styles.editor} value={input} disabled={busy || Boolean(pending)} spellCheck="false" onChange={event => setInput(event.target.value)} />
        <div className="actions"><button className="primary" disabled={busy || Boolean(pending)} onClick={run}>{isSimulationMode ? t('simulator.runSimulation') : t('simulator.runReal')}</button><button disabled={phase !== 'Running'} onClick={() => controller.current?.abort()}>{t('simulator.cancel')}</button></div>
        {pending && <div className="actions mt-4"><button disabled={busy} onClick={async () => { if (lock.current) return; lock.current = true; setError(''); await persist(pending); lock.current = false; }}>{t('simulator.retrySave')}</button><button disabled={busy} onClick={() => { setPending(null); setError(''); setPhase('Finished'); }}>{t('simulator.discard')}</button></div>}
        {error && <p role="alert" className="error-text">{error}</p>}
      </div>
      <div className="panel">
        <div className="flex justify-between gap-4"><p className="eyebrow">{t('simulator.execution')}</p><span className="badge" role="status">{t(`simulator.phase.${phase}`)}</span></div>
        <div className={styles.track} role="progressbar" aria-label={t('simulator.progress')} aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(progress)}><motion.div animate={{ width: `${progress}%` }} /></div>
        <ol className={styles.stages}>{executionStages.map((stage, index) => <li key={`${stage}-${index}`} data-active={index === step && busy} data-done={index < step}><span className="tiny">{String(index + 1).padStart(2, '0')}</span><span>{stage}</span><span className="tiny">{index < step ? t('simulator.state.Done') : index === step && phase === 'Running' ? t('simulator.state.Running') : t('simulator.state.Pending')}</span></li>)}</ol>
        <p className="muted tiny">{t('simulator.conditional', { condition: localized.condition })}</p>
      </div>
    </div>
    {result && <section className="panel mt-6"><p className="eyebrow">{isSimulationMode ? t('simulator.outputSimulation') : t('simulator.outputReal')}</p><h2>{result.message}</h2><pre className={styles.output}>{JSON.stringify(result.output, null, 2)}</pre><div className="actions"><button onClick={() => downloadJson(`${id}-${isSimulationMode ? 'simulation' : 'n8n'}.json`, result)}>{t('simulator.download')}</button><Link className="text-link" to="/logs">{t('simulator.viewLogs')}</Link></div></section>}
  </section>;
}
