# Internationalization implementation

## Installation

Install all project dependencies:

```bash
npm install
```

For an existing clone that only needs the internationalization packages:

```bash
npm install i18next react-i18next i18next-browser-languagedetector
```

Framer Motion is already included in the project. No HTTP backend is required because the six translation dictionaries are imported directly by `src/i18n.js`.

## Supported languages

The application supports exactly these six language codes:

1. `en` English
2. `zh` Mandarin Chinese
3. `hi` Hindi
4. `es` Spanish
5. `fr` French
6. `ar` Arabic

The selector contains text labels only. It does not use flags, emoji, pictographic symbols or iconography.

## Central configuration

The complete configuration is implemented in `src/i18n.js`. It uses `i18next-browser-languagedetector` in this order:

1. `localStorage`, key `hub-language`
2. Browser language through `navigator`

The selected language is cached in `localStorage`. The helper `applyDocumentLanguage` sets both the `lang` and `dir` attributes on the root `html` element. Arabic receives `dir="rtl"`. Every other supported language receives `dir="ltr"`.

## Translation dictionaries

The complete dictionaries are stored at:

```text
src/locales/en/translation.json
src/locales/zh/translation.json
src/locales/hi/translation.json
src/locales/es/translation.json
src/locales/fr/translation.json
src/locales/ar/translation.json
```

Each dictionary uses the same key structure. The main groups are:

```json
{
  "layout": {
    "overview": "...",
    "workflows": "...",
    "simulator": "...",
    "logs": "..."
  },
  "hero": {
    "title1": "...",
    "title2": "...",
    "description": "...",
    "explore": "...",
    "launch": "..."
  },
  "dashboard": {
    "businessWorkflows": "...",
    "themes": "...",
    "runs": "...",
    "completed": "...",
    "title": "..."
  },
  "solutions": {
    "finance": {
      "department": "...",
      "title": "...",
      "description": "..."
    },
    "hr": {
      "department": "...",
      "title": "...",
      "description": "..."
    },
    "support": {
      "department": "...",
      "title": "...",
      "description": "..."
    },
    "sales": {
      "department": "...",
      "title": "...",
      "description": "..."
    },
    "logistics": {
      "department": "...",
      "title": "...",
      "description": "..."
    }
  }
}
```

The actual dictionaries go further and also translate trigger descriptions, processing steps, conditions, expected outputs, simulator stages, logs, theme controls, video controls, market status and error-state interface text.

## Language selector

The complete selector is implemented in `src/Componentes/LanguageSwitcher.jsx`.

It provides:

1. `AnimatePresence` and `motion` transitions for opacity and Y position.
2. `aria-haspopup`, `aria-expanded`, `aria-controls`, `role="menu"` and `role="menuitemradio"`.
3. Arrow Up and Arrow Down keyboard navigation.
4. Escape handling.
5. Focus return to the trigger after selection.
6. Outside-click closing.
7. `localStorage` persistence.
8. Immediate `html` direction updates.

## Application provider

The provider is installed in `src/main.jsx` around the entire application:

```jsx
import React from 'react';
import ReactDOM from 'react-dom/client';
import { I18nextProvider } from 'react-i18next';
import App from './App';
import i18n from './i18n';
import './styles.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <I18nextProvider i18n={i18n}>
      <App />
    </I18nextProvider>
  </React.StrictMode>
);
```

Because `I18nextProvider` wraps `App`, every page rendered by React Router has access to `useTranslation` and updates immediately when `i18n.changeLanguage` is called.

## Navbar integration

`LanguageSwitcher` is imported into `src/Componentes/Layout.jsx` and rendered inside `.topbar-actions`, next to the appearance control. Since `Layout` wraps every route, the language selector remains available throughout the application.

## RTL styling

`src/styles.css` uses logical CSS properties such as:

```css
border-inline-start
border-inline-end
padding-inline-start
margin-inline-start
inset-inline-start
inset-inline-end
```

Additional `[dir="rtl"]` rules invert the theme panel position, hero overlay and other direction-sensitive areas. This makes Arabic layout behavior structural rather than only changing text alignment.

## Validation

The six locale dictionaries were checked for complete key parity after the n8n integration changes. The current domain suite passes 12 of 12 tests, JSON files parse correctly and the generated source was scanned for emoji and pictographic code points.

The dependency installation and Vite build could not be completed in the generation environment because the package download did not finish within the available execution window. On a normal development machine, run:

```bash
npm install
npm run build
npm run dev
```
