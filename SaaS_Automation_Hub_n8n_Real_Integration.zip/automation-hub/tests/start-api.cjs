const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawn } = require('node:child_process');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'hub-test-'));
const database = path.join(dir, 'db.json');
fs.copyFileSync(path.join(__dirname, '..', 'db.json'), database);
const child = spawn(process.execPath, ['server.js'], { cwd: path.join(__dirname, '..'), env: { ...process.env, DB_PATH:database }, stdio:'inherit' });
function stop() { child.kill(); }
process.on('SIGTERM', stop); process.on('SIGINT', stop);
child.on('exit', code => { fs.rmSync(dir, { recursive:true, force:true }); process.exit(code || 0); });
