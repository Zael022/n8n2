import { useRef, useState } from 'react';
import ReactPlayer from 'react-player/file';
import { useTranslation } from 'react-i18next';
import { localizeWorkflow } from '../lib/localizeWorkflow';

export default function VideoDemo({ workflow }) {
  const { t } = useTranslation();
  const localized = localizeWorkflow(workflow, t);
  const [playing, setPlaying] = useState(false);
  const [error, setError] = useState(false);
  const [position, setPosition] = useState(0);
  const [duration, setDuration] = useState(1);
  const ref = useRef(null);
  return <section className="panel demo"><p className="eyebrow">{t('video.eyebrow')}</p><h2>{t('video.title')}</h2>
    <div className="demo-video"><ReactPlayer ref={ref} url={workflow.local_demo_url} playing={playing} controls={false} width="100%" height="100%" onError={() => { setError(true); setPlaying(false); }} onDuration={setDuration} onProgress={({ playedSeconds }) => setPosition(playedSeconds)} onEnded={() => setPlaying(false)} /></div>
    {error ? <p role="alert">{t('video.failed')}</p> : <div className="actions"><button onClick={() => setPlaying(value => !value)}>{playing ? t('video.pause') : t('video.play')}</button><button onClick={() => { ref.current?.seekTo(0, 'seconds'); setPosition(0); setPlaying(true); }}>{t('video.restart')}</button><label className="seek">{t('video.position')}<input aria-label={t('video.position')} type="range" min="0" max={duration} step="0.1" value={position} onChange={event => { const value = Number(event.target.value); ref.current?.seekTo(value, 'seconds'); setPosition(value); }} /></label></div>}
    <details><summary>{t('video.transcript')}</summary><p>{localized.business_problem}</p><p>{t('video.trigger', { value: localized.trigger_used })}</p><ol>{localized.processing_nodes.map(node => <li key={node}>{node}</li>)}</ol><p>{localized.condition}</p><p>{localized.expected_output}</p></details>
  </section>;
}
