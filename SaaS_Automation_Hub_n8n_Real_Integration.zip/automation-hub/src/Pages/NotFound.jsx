import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

export default function NotFound() {
  const { t } = useTranslation();
  return <section className="panel empty"><p className="eyebrow">{t('notFound.eyebrow')}</p><h1>{t('notFound.title')}</h1><Link className="button" to="/">{t('notFound.return')}</Link></section>;
}
