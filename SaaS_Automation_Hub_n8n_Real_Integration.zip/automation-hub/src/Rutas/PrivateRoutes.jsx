import { Navigate, Outlet, useLocation } from 'react-router-dom';
export default function PrivateRoutes({ authorized = false }) {
  const location = useLocation();
  return authorized ? <Outlet/> : <Navigate to="/" replace state={{ from: location.pathname }}/>;
}
// Reserved for a future authenticated route tree. All current simulator routes are public.
// Client routing is not server authorization.
