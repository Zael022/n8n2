import { useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useHub } from '../Context/HubContext';
import { localizeWorkflows } from '../lib/localizeWorkflow';
import WorkflowCard from '../Componentes/WorkflowCard';

export default function Workflows() {
  const { t } = useTranslation();
  const { workflows } = useHub();
  const [query, setQuery] = useState('');
  const localized = localizeWorkflows(workflows, t);
  const visible = useMemo(() => localized.filter(workflow => `${workflow.title} ${workflow.department} ${workflow.business_problem}`.toLowerCase().includes(query.toLowerCase())), [query, localized]);
  return <section>
    <p className="eyebrow">{t('workflows.eyebrow')}</p>
    <h1>{t('workflows.title')}</h1>
    <p className="muted lead">{t('workflows.description')}</p>
    <label className="search">{t('workflows.searchLabel')}<input type="search" placeholder={t('workflows.searchPlaceholder')} value={query} onChange={event => setQuery(event.target.value)} /></label>
    <div className="workflow-grid">{visible.map(workflow => <WorkflowCard key={workflow.id} workflow={workflow} index={workflows.findIndex(item => item.id === workflow.id)} />)}</div>
    {!visible.length && <p role="status">{t('workflows.none')}</p>}
  </section>;
}
