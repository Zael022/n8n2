import { Link, useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useHub } from '../Context/HubContext';
import { localizeWorkflow } from '../lib/localizeWorkflow';
import VideoDemo from '../Componentes/VideoDemo';
import NotFound from './NotFound';

export default function FlowDetails() {
  const { id } = useParams();
  const { t } = useTranslation();
  const { workflows, loading, error } = useHub();
  const workflow = workflows.find(item => item.id === id);
  if (!workflow) return loading || error ? null : <NotFound />;
  const localized = localizeWorkflow(workflow, t);
  const steps = [localized.trigger_used, ...localized.processing_nodes, localized.expected_output];
  return <>
    <Link className="text-link" to="/workflows">{t('details.back')}</Link>
    <p className="eyebrow mt-8">{localized.department} / {t('details.design')}</p>
    <h1>{localized.title}</h1>
    <p className="muted lead">{localized.business_problem}</p>
    <Link className="button primary" to={`/simulator/${id}`}>{t('details.simulate')}</Link>
    <section className="panel flow-section">
      <h2>{t('details.title')}</h2>
      <ol className="flow-diagram">{steps.map((step, index) => <li key={`${step}-${index}`}><span className="step-index">{String(index + 1).padStart(2, '0')}</span><div><p className="eyebrow">{index === 0 ? t('details.trigger') : index === steps.length - 1 ? t('details.output') : t('details.processing')}</p><p>{step}</p></div></li>)}</ol>
      <div className="condition"><p className="eyebrow">{t('details.condition')}</p><p>{localized.condition}</p></div>
    </section>
    <VideoDemo workflow={workflow} />
  </>;
}
