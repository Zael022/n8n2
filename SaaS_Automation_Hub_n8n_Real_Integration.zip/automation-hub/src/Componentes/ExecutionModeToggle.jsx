import { useTranslation } from 'react-i18next';
import { useExecutionMode } from '../Context/ExecutionModeContext';

export default function ExecutionModeToggle() {
  const { t } = useTranslation();
  const { isSimulationMode, setSimulationMode } = useExecutionMode();
  const mode = isSimulationMode ? 'simulation' : 'real';

  return <div className="execution-mode" aria-label={t('executionMode.group')}>
    <span className="execution-mode-label">{t(`executionMode.${mode}`)}</span>
    <button
      type="button"
      className="mode-switch"
      role="switch"
      aria-checked={isSimulationMode}
      aria-label={t('executionMode.toggleAria')}
      title={t('executionMode.help')}
      onClick={() => setSimulationMode(!isSimulationMode)}
    >
      <span className="mode-switch-track" aria-hidden="true"><span className="mode-switch-thumb" /></span>
    </button>
  </div>;
}
