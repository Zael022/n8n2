import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { simulateResult, pageItems } from '../src/lib/simulate.js';
import { themes, resolveTheme } from '../src/lib/themes.js';
const { workflows, logs } = JSON.parse(fs.readFileSync(new URL('../db.json', import.meta.url)));
test('Twelve themes in four groups, with valid fallback', () => {
  assert.equal(new Set(themes.map(theme => theme.id)).size, 12);
  for (const mode of new Set(themes.map(theme => theme.mode))) assert.equal(themes.filter(theme => theme.mode === mode).length, 3);
  assert.equal(resolveTheme('invalid').id, 'classic-dark');
});
for (const workflow of workflows) test(`${workflow.id}: sample and alternate follow business conditions`, () => {
  const primary = simulateResult(workflow.id, workflow.sample_input);
  const alternate = simulateResult(workflow.id, workflow.alternate_input);
  assert.equal(primary.status, 'Completed');
  assert.notDeepEqual(primary.output, alternate.output);
});
test('Boundary score 70 routes to senior seller; 69 to nurturing', () => {
  const input = workflows.find(workflow => workflow.id === 'sales').sample_input;
  assert.equal(simulateResult('sales', { ...input, score:70 }).output.route, 'senior-seller');
  assert.equal(simulateResult('sales', { ...input, score:69 }).output.route, 'email-nurturing');
});
test('Stock equal to minimum does not trigger reorder', () => {
  assert.equal(simulateResult('logistics', { products:[{ sku:'A', stock:4, minimum:4 }] }).status, 'No action');
});
test('Malformed data cannot complete a flow', () => {
  assert.throws(() => simulateResult('hr', {}));
  assert.throws(() => simulateResult('support', { message:'' }));
  assert.throws(() => simulateResult('logistics', { products:[null] }));
  assert.equal(simulateResult('finance', {}).status, 'Rejected');
  assert.equal(simulateResult('sales', { email:'bad' }).status, 'Rejected');
});
test('27 seed logs produce three disjoint pages of nine', () => {
  const pages = [1,2,3].map(page => pageItems(logs, page));
  pages.forEach(page => assert.equal(page.length, 9));
  assert.equal(new Set(pages.flat().map(log => log.id)).size, 27);
  assert.equal(pageItems(logs, 4).length, 0);
});
