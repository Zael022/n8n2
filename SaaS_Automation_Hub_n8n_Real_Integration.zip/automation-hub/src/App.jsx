import { BrowserRouter } from 'react-router-dom';
import { MotionConfig } from 'framer-motion';
import { ThemeProvider } from './Context/ThemeContext';
import { HubProvider } from './Context/HubContext';
import { ExecutionModeProvider } from './Context/ExecutionModeContext';
import Routing from './Rutas/Routing';

export default function App() {
  return <MotionConfig reducedMotion="user">
    <ThemeProvider>
      <ExecutionModeProvider>
        <HubProvider>
          <BrowserRouter><Routing /></BrowserRouter>
        </HubProvider>
      </ExecutionModeProvider>
    </ThemeProvider>
  </MotionConfig>;
}
