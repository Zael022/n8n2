import { useCallback, useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useHub } from '../Context/HubContext';
import { useTheme } from '../Context/ThemeContext';
import LanguageSwitcher from './LanguageSwitcher';
import ExecutionModeToggle from './ExecutionModeToggle';
import ThemePanel from './ThemePanel';

export default function Layout({ children }) {
  const [themeOpen, setThemeOpen] = useState(false);
  const closeTheme = useCallback(() => setThemeOpen(false), []);
  const { t } = useTranslation();
  const { selectedTheme } = useTheme();
  const { loading, error, refresh } = useHub();
  return <div className="app-shell">
    <a className="skip-link" href="#main">{t('layout.skip')}</a>
    <aside className="sidebar">
      <Link className="brand" to="/">AUTOMATION<span>HUB</span></Link>
      <p className="workspace-label">{t('layout.workspace')}</p>
      <nav aria-label={t('layout.operations')}>
        <NavLink to="/" end>{t('layout.overview')}</NavLink>
        <NavLink to="/workflows">{t('layout.workflows')} <span>05</span></NavLink>
        <NavLink to="/simulator/finance">{t('layout.simulator')}</NavLink>
        <NavLink to="/logs">{t('layout.logs')}</NavLink>
      </nav>
      <div className="sidebar-bottom">
        <p className="tiny muted">{t('layout.connect')}</p>
        <p>{t('layout.ideas')}</p>
        <p className="tiny muted">{t('layout.local').split('\n').map((line, index) => <span key={line}>{index > 0 && <br />}{line}</span>)}</p>
      </div>
    </aside>
    <div className="main-shell">
      <header className="topbar">
        <span>{t('layout.operations')} <span className="muted">/ {t('layout.quiz')}</span></span>
        <div className="topbar-actions">
          <ExecutionModeToggle />
          <LanguageSwitcher />
          <button onClick={() => setThemeOpen(true)}>{t('layout.appearance', { theme: selectedTheme.name })}</button>
        </div>
      </header>
      <main id="main" tabIndex="-1">
        {error && <div className="error-panel" role="alert"><p>{error}</p><button disabled={loading} onClick={() => refresh()}>{t('layout.retry')}</button></div>}
        {loading && <p role="status" className="loading">{t('layout.loading')}</p>}
        {children}
      </main>
      <footer><span>SaaS Automation Hub &amp; n8n</span><span>{t('layout.footer')}</span></footer>
    </div>
    <ThemePanel open={themeOpen} onClose={closeTheme} />
  </div>;
}
