import express from 'express';
import dotenv from 'dotenv';
import { promises as fs } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = Number(process.env.PORT || 3001);
const HOST = process.env.HOST || '127.0.0.1';
const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'db.json');
const N8N_WEBHOOK_BASE_URL = (process.env.N8N_WEBHOOK_BASE_URL || 'http://127.0.0.1:5678/webhook').replace(/\/$/, '');
const N8N_TIMEOUT_MS = Math.max(1000, Number(process.env.N8N_TIMEOUT_MS || 30000));

const workflowPaths = Object.freeze({
  finance: process.env.N8N_FINANCE_WEBHOOK_PATH || 'finance',
  hr: process.env.N8N_HR_WEBHOOK_PATH || 'hr',
  support: process.env.N8N_SUPPORT_WEBHOOK_PATH || 'support',
  sales: process.env.N8N_SALES_WEBHOOK_PATH || 'sales',
  logistics: process.env.N8N_LOGISTICS_WEBHOOK_PATH || 'logistics'
});

app.disable('x-powered-by');
app.use(express.json({ limit: '1mb' }));

async function readDatabase() {
  const content = await fs.readFile(DB_PATH, 'utf8');
  return JSON.parse(content);
}

async function writeDatabase(database) {
  const temporaryPath = `${DB_PATH}.tmp`;
  await fs.writeFile(temporaryPath, `${JSON.stringify(database, null, 2)}\n`, 'utf8');
  await fs.rename(temporaryPath, DB_PATH);
}

function structuredError(res, status, code, message, details) {
  return res.status(status).json({
    status: 'error',
    error: {
      code,
      message,
      ...(details ? { details } : {})
    },
    timestamp: new Date().toISOString()
  });
}

app.get('/health', (_req, res) => {
  res.json({ status: 'online', service: 'automation-hub-proxy' });
});

app.get('/api/health', (_req, res) => {
  res.json({ status: 'online', service: 'automation-hub-proxy' });
});

app.get('/api/workflows', async (_req, res) => {
  try {
    const database = await readDatabase();
    res.json(database.workflows || []);
  } catch (error) {
    structuredError(res, 500, 'DATABASE_READ_FAILED', 'Unable to read workflow data.', error.message);
  }
});

app.get('/api/logs', async (_req, res) => {
  try {
    const database = await readDatabase();
    const logs = [...(database.logs || [])].sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    res.json(logs);
  } catch (error) {
    structuredError(res, 500, 'DATABASE_READ_FAILED', 'Unable to read execution logs.', error.message);
  }
});

app.post('/api/logs', async (req, res) => {
  try {
    const database = await readDatabase();
    const workflow = (database.workflows || []).find(item => item.id === req.body.workflow_id);
    const allowedStatuses = new Set(['Completed', 'Rejected', 'No action']);
    const id = String(req.body.id || '');

    if (!workflow || !allowedStatuses.has(req.body.status) || typeof req.body.message !== 'string' || req.body.message.length > 2000) {
      return structuredError(res, 400, 'INVALID_EXECUTION_LOG', 'Execution log validation failed.');
    }
    if (!/^[a-zA-Z0-9-]{10,80}$/.test(id)) {
      return structuredError(res, 400, 'INVALID_EXECUTION_ID', 'Execution ID validation failed.');
    }

    const existing = (database.logs || []).find(item => item.id === id);
    if (existing) return res.json(existing);

    const log = {
      id,
      workflow_id: workflow.id,
      title: workflow.title,
      department: workflow.department,
      status: req.body.status,
      message: req.body.message,
      timestamp: new Date().toISOString(),
      duration_ms: Math.max(0, Math.min(3600000, Number(req.body.duration_ms) || 0)),
      simulated: Boolean(req.body.simulated),
      seed: false
    };

    database.logs = [...(database.logs || []), log];
    await writeDatabase(database);
    return res.status(201).json(log);
  } catch (error) {
    return structuredError(res, 500, 'DATABASE_WRITE_FAILED', 'Unable to persist the execution log.', error.message);
  }
});

app.post('/api/n8n/execute/:workflowName', async (req, res) => {
  const workflowName = String(req.params.workflowName || '').toLowerCase();
  const webhookPath = workflowPaths[workflowName];
  if (!webhookPath) {
    return structuredError(res, 404, 'UNKNOWN_WORKFLOW', 'The requested workflow is not configured.');
  }
  if (!req.body || typeof req.body !== 'object' || Array.isArray(req.body)) {
    return structuredError(res, 400, 'INVALID_PAYLOAD', 'The workflow payload must be a JSON object.');
  }

  const encodedWebhookPath = webhookPath.split('/').filter(Boolean).map(encodeURIComponent).join('/');
  const targetUrl = `${N8N_WEBHOOK_BASE_URL}/${encodedWebhookPath}`;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), N8N_TIMEOUT_MS);

  try {
    const upstream = await fetch(targetUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(req.body),
      signal: controller.signal
    });

    const rawBody = await upstream.text();
    let data;
    try {
      data = rawBody ? JSON.parse(rawBody) : {};
    } catch {
      return structuredError(res, 502, 'N8N_INVALID_RESPONSE', 'n8n returned a non-JSON response.', { upstreamStatus: upstream.status });
    }

    if (!upstream.ok) {
      return structuredError(res, 502, 'N8N_WEBHOOK_FAILED', 'n8n rejected or failed the workflow execution.', {
        upstreamStatus: upstream.status,
        upstreamResponse: data
      });
    }

    return res.status(200).json({
      status: 'completed',
      workflow: workflowName,
      data,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    if (error.name === 'AbortError') {
      return structuredError(res, 502, 'N8N_TIMEOUT', `n8n did not respond within ${N8N_TIMEOUT_MS} ms.`);
    }
    return structuredError(res, 502, 'N8N_UNREACHABLE', 'The n8n webhook could not be reached.', error.message);
  } finally {
    clearTimeout(timeout);
  }
});

app.use((error, _req, res, _next) => {
  if (error?.type === 'entity.parse.failed') {
    return structuredError(res, 400, 'INVALID_JSON', 'The request body contains invalid JSON.');
  }
  return structuredError(res, 500, 'INTERNAL_SERVER_ERROR', 'Unexpected backend error.');
});

const listener = app.listen(PORT, HOST, () => {
  console.log(`Automation Hub proxy listening on http://${HOST}:${PORT}`);
});

listener.on('error', error => {
  console.error(error.code === 'EADDRINUSE' ? 'Backend port is occupied. Stop the existing process or choose another port.' : error.message);
  process.exit(1);
});
