import { useEffect } from 'react';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { Route, Routes, useLocation } from 'react-router-dom';
import Layout from '../Componentes/Layout';
import Dashboard from '../Pages/Dashboard';
import Workflows from '../Pages/Workflows';
import FlowDetails from '../Pages/FlowDetails';
import Simulator from '../Pages/Simulator';
import Logs from '../Pages/Logs';
import NotFound from '../Pages/NotFound';
export default function Routing() {
  const location = useLocation();
  const reduced = useReducedMotion();
  useEffect(() => { window.scrollTo(0, 0); }, [location.pathname]);
  return <Layout><AnimatePresence mode="wait" initial={false}>
    <motion.div key={location.pathname} initial={{ opacity: 0, y: reduced ? 0 : 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: reduced ? 0 : -8 }} transition={{ duration: reduced ? 0 : 0.18 }}>
      <Routes location={location}>
        <Route path="/" element={<Dashboard/>}/>
        <Route path="/workflows" element={<Workflows/>}/>
        <Route path="/workflows/:id" element={<FlowDetails/>}/>
        <Route path="/simulator/:id" element={<Simulator/>}/>
        <Route path="/logs" element={<Logs/>}/>
        <Route path="*" element={<NotFound/>}/>
      </Routes>
    </motion.div>
  </AnimatePresence></Layout>;
}
