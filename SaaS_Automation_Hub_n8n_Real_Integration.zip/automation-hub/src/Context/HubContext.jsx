import { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { request } from '../lib/api';
const HubContext = createContext(null);
export function HubProvider({ children }) {
  const [workflows, setWorkflows] = useState([]);
  const [logs, setLogs] = useState([]);
  const [page, setPage] = useState(1);
  const [direction, setDirection] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const refresh = useCallback(async signal => {
    setLoading(true); setError('');
    try {
      const [nextWorkflows, nextLogs] = await Promise.all([request('/workflows', { signal }), request('/logs?_sort=timestamp&_order=desc', { signal })]);
      if (!Array.isArray(nextWorkflows) || !Array.isArray(nextLogs)) throw new Error('Invalid API data');
      setWorkflows(nextWorkflows); setLogs(nextLogs);
    } catch (err) { if (!signal?.aborted) setError(err.message); }
    finally { if (!signal?.aborted) setLoading(false); }
  }, []);
  useEffect(() => { const controller = new AbortController(); refresh(controller.signal); return () => controller.abort(); }, [refresh]);
  const saveLog = async log => {
    const saved = await request('/logs', { method: 'POST', body: JSON.stringify(log) });
    setLogs(previous => [saved, ...previous.filter(item => item.id !== saved.id)]);
    return saved;
  };
  return <HubContext.Provider value={{ workflows, logs, page, setPage, direction, setDirection, loading, error, refresh, saveLog }}>{children}</HubContext.Provider>;
}
export function useHub() { return useContext(HubContext); }
